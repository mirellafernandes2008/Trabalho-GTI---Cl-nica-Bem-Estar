import mysql.connector
from mysql.connector import Error


def conectar():
    try:
        conexao = mysql.connector.connect(
            host='localhost',
            port=3306,
            user='root',
            password='8082',
            database='clinica_bem_estar'
        )

        if conexao.is_connected():
            print("Conectado ao MySQL")
            return conexao

    except Error as e:
        print("Erro:", e)
        return None


def fechar_conexao(conexao):
    if conexao and conexao.is_connected():
        conexao.close()