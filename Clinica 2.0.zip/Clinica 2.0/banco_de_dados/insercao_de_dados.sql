USE clinica_bem_estar;

INSERT INTO tbl_pacientes
(nome_paciente, telefone_paciente, cpf_paciente, email_paciente)
VALUES
('Bianca Palma', '11978799327', '552.622.238-18', 'palmabianca2201@gmail.com'),
('Mirella Fernandes', '11978629077', '540.033.328-14', 'mirella.2022.fernandes@gmail.com');

INSERT INTO tbl_agendamentos
(data_hora_agendamento, lab_agendamento, fk_paciente)
VALUES
('2026-05-14 11:00:00', 'Lab 04', 2),
('2026-05-15 16:00:00', 'Lab 07', 1);

INSERT INTO tbl_feedbacks
(profissional_feedback, fk_paciente)
VALUES
('Carla Machado', 1),
('Gabriel Matheus', 2);

UPDATE tbl_pacientes
SET telefone_paciente = '11999999999'
WHERE id_paciente = 1;

SELECT
    tbl_pacientes.nome_paciente,
    tbl_pacientes.telefone_paciente,
    tbl_pacientes.cpf_paciente,
    tbl_pacientes.email_paciente,
    tbl_agendamentos.data_hora_agendamento,
    tbl_agendamentos.lab_agendamento,
    tbl_feedbacks.profissional_feedback
FROM tbl_pacientes
INNER JOIN tbl_agendamentos
ON tbl_pacientes.id_paciente = tbl_agendamentos.fk_paciente
INNER JOIN tbl_feedbacks
ON tbl_pacientes.id_paciente = tbl_feedbacks.fk_paciente
ORDER BY nome_paciente;