from banco_de_dados.conexao import conectar, fechar_conexao


# ================= PACIENTES =================
def listar_pacientes():
    conexao = conectar()
    cursor = conexao.cursor()

    cursor.execute("SELECT * FROM tbl_pacientes")
    dados = cursor.fetchall()

    print("\n===== PACIENTES =====")
    for paciente in dados:
        print(
            f"ID: {paciente[0]} | "
            f"Nome: {paciente[1]} | "
            f"Telefone: {paciente[2]} | "
            f"CPF: {paciente[3]} | "
            f"Email: {paciente[4]}"
        )

    cursor.close()
    fechar_conexao(conexao)


def adicionar_paciente():
    nome = input("Nome: ")
    telefone = input("Telefone: ")
    cpf = input("CPF: ")
    email = input("Email: ")

    conexao = conectar()
    cursor = conexao.cursor()

    sql = """
    INSERT INTO tbl_pacientes
    (nome_paciente, telefone_paciente, cpf_paciente, email_paciente)
    VALUES (%s, %s, %s, %s)
    """

    cursor.execute(sql, (nome, telefone, cpf, email))
    conexao.commit()

    print("Paciente adicionado!")

    cursor.close()
    fechar_conexao(conexao)

def editar_paciente():
    id_paciente = input("ID do paciente: ")

    novo_nome = input("Novo nome: ")
    novo_telefone = input("Novo telefone: ")
    novo_cpf = input("Novo CPF: ")
    novo_email = input("Novo email: ")

    conexao = conectar()
    cursor = conexao.cursor()

    cursor.execute(
        """
        UPDATE tbl_pacientes
        SET nome_paciente=%s,
            telefone_paciente=%s,
            cpf_paciente=%s,
            email_paciente=%s
        WHERE id_paciente=%s
        """,
        (
            novo_nome,
            novo_telefone,
            novo_cpf,
            novo_email,
            id_paciente
        )
    )

    conexao.commit()

    print("Paciente atualizado!")

    cursor.close()
    fechar_conexao(conexao)

def excluir_paciente():
    id_paciente = input("ID do paciente: ")

    conexao = conectar()
    cursor = conexao.cursor()

    # apaga agendamentos do paciente
    cursor.execute(
        "DELETE FROM tbl_agendamentos WHERE fk_paciente=%s",
        (id_paciente,)
    )

    # apaga feedbacks do paciente
    cursor.execute(
        "DELETE FROM tbl_feedbacks WHERE fk_paciente=%s",
        (id_paciente,)
    )

    # agora apaga o paciente
    cursor.execute(
        "DELETE FROM tbl_pacientes WHERE id_paciente=%s",
        (id_paciente,)
    )

    conexao.commit()
    print("Paciente excluído!")

    cursor.close()
    fechar_conexao(conexao)
    
# ================= AGENDAMENTOS =================
def listar_agendamentos():
    conexao = conectar()
    cursor = conexao.cursor()

    cursor.execute("SELECT * FROM tbl_agendamentos")
    dados = cursor.fetchall()

    print("\n===== AGENDAMENTOS =====")
    for agendamento in dados:
        print(
            f"ID: {agendamento[0]} | "
            f"Data: {agendamento[1]} | "
            f"Laboratório: {agendamento[2]} | "
            f"ID Paciente: {agendamento[3]}"
        )

    cursor.close()
    fechar_conexao(conexao)


def adicionar_agendamento():
    data = input("Data e hora (AAAA-MM-DD HH:MM:SS): ")
    lab = input("Laboratório: ")
    fk = input("ID do paciente: ")

    conexao = conectar()
    cursor = conexao.cursor()

    sql = """
    INSERT INTO tbl_agendamentos
    (data_hora_agendamento, lab_agendamento, fk_paciente)
    VALUES (%s, %s, %s)
    """

    cursor.execute(sql, (data, lab, fk))
    conexao.commit()

    print("Agendamento adicionado!")

    cursor.close()
    fechar_conexao(conexao)

def editar_agendamento():
    id_agendamento = input("ID do agendamento: ")
    nova_data = input("Nova data (AAAA-MM-DD HH:MM:SS): ")
    novo_lab = input("Novo laboratório: ")

    conexao = conectar()
    cursor = conexao.cursor()

    cursor.execute(
        """
        UPDATE tbl_agendamentos
        SET data_hora_agendamento=%s,
            lab_agendamento=%s
        WHERE id_agendamento=%s
        """,
        (nova_data, novo_lab, id_agendamento)
    )

    conexao.commit()
    print("Agendamento atualizado!")

    cursor.close()
    fechar_conexao(conexao)

def excluir_agendamento():
    id_agendamento = input("ID do agendamento: ")

    conexao = conectar()
    cursor = conexao.cursor()

    cursor.execute(
        "DELETE FROM tbl_agendamentos WHERE id_agendamento=%s",
        (id_agendamento,)
    )

    conexao.commit()
    print("Agendamento excluído!")

    cursor.close()
    fechar_conexao(conexao)


# ================= FEEDBACKS =================
def listar_feedbacks():
    conexao = conectar()
    cursor = conexao.cursor()

    cursor.execute("SELECT * FROM tbl_feedbacks")
    dados = cursor.fetchall()

    print("\n===== FEEDBACKS =====")
    for feedback in dados:
        print(
            f"ID: {feedback[0]} | "
            f"Profissional: {feedback[1]} | "
            f"ID Paciente: {feedback[2]}"
        )

    cursor.close()
    fechar_conexao(conexao)


def adicionar_feedback():
    profissional = input("Nome do profissional: ")
    fk = input("ID do paciente: ")

    conexao = conectar()
    cursor = conexao.cursor()

    sql = """
    INSERT INTO tbl_feedbacks
    (profissional_feedback, fk_paciente)
    VALUES (%s, %s)
    """

    cursor.execute(sql, (profissional, fk))
    conexao.commit()

    print("Feedback adicionado!")

    cursor.close()
    fechar_conexao(conexao)


def editar_feedback():
    id_feedback = input("ID do feedback: ")
    novo_profissional = input("Novo profissional: ")

    conexao = conectar()
    cursor = conexao.cursor()

    cursor.execute(
        """
        UPDATE tbl_feedbacks
        SET profissional_feedback=%s
        WHERE id_feedback=%s
        """,
        (novo_profissional, id_feedback)
    )

    conexao.commit()
    print("Feedback atualizado!")

    cursor.close()
    fechar_conexao(conexao)


def excluir_feedback():
    id_feedback = input("ID do feedback: ")

    conexao = conectar()
    cursor = conexao.cursor()

    cursor.execute(
        "DELETE FROM tbl_feedbacks WHERE id_feedback=%s",
        (id_feedback,)
    )

    conexao.commit()
    print("Feedback excluído!")

    cursor.close()
    fechar_conexao(conexao)