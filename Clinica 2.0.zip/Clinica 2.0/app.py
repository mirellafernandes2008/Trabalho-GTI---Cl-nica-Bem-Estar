from flask import Flask, send_from_directory, request, redirect, jsonify
from banco_de_dados.conexao import conectar, fechar_conexao

app = Flask(__name__)


# ---------------- HOME ----------------
@app.route('/')
def home():
    return send_from_directory('templates', 'index.html')


# ---------------- PAINEL ----------------
@app.route('/painel')
def painel():
    return send_from_directory('templates', 'painel.html')


# ---------------- CADASTRO SITE ----------------
@app.route('/cadastro', methods=['POST'])
def cadastro():

    nome = request.form['nome_paciente']
    telefone = request.form['telefone_paciente']
    cpf = request.form['cpf_paciente']
    email = request.form['email_paciente']

    conexao = conectar()

    if conexao:

        cursor = conexao.cursor()

        sql = '''
        INSERT INTO tbl_pacientes
        (nome_paciente, telefone_paciente, cpf_paciente, email_paciente)
        VALUES (%s, %s, %s, %s)
        '''

        cursor.execute(sql, (nome, telefone, cpf, email))

        conexao.commit()

        cursor.close()
        fechar_conexao(conexao)

    return redirect('/')


# ---------------- AGENDAMENTO SITE ----------------
@app.route('/agendamento', methods=['POST'])
def agendamento():

    nome = request.form['nome_paciente_agendamento']
    data = request.form['data_hora_agendamento']
    lab = request.form['lab_agendamento']

    conexao = conectar()

    if conexao:

        cursor = conexao.cursor()

        sql_busca = '''
        SELECT id_paciente
        FROM tbl_pacientes
        WHERE nome_paciente = %s
        '''

        cursor.execute(sql_busca, (nome,))

        paciente = cursor.fetchone()

        if paciente:

            id_paciente = paciente[0]

            sql = '''
            INSERT INTO tbl_agendamentos
            (data_hora_agendamento, lab_agendamento, fk_paciente)
            VALUES (%s, %s, %s)
            '''

            cursor.execute(sql, (data, lab, id_paciente))

            conexao.commit()

        cursor.close()
        fechar_conexao(conexao)

    return redirect('/')


# ---------------- FEEDBACK SITE ----------------
@app.route('/feedback', methods=['POST'])
def feedback():

    nome = request.form['nome_paciente']
    profissional = request.form['profissional_feedbacks']

    conexao = conectar()

    if conexao:

        cursor = conexao.cursor()

        sql_busca = '''
        SELECT id_paciente
        FROM tbl_pacientes
        WHERE nome_paciente = %s
        '''

        cursor.execute(sql_busca, (nome,))

        paciente = cursor.fetchone()

        if paciente:

            id_paciente = paciente[0]

            sql = '''
            INSERT INTO tbl_feedbacks
            (profissional_feedback, fk_paciente)
            VALUES (%s, %s)
            '''

            cursor.execute(sql, (profissional, id_paciente))

            conexao.commit()

        cursor.close()
        fechar_conexao(conexao)

    return redirect('/')


# ==================================================
# API DO PAINEL
# ==================================================

# ==================================================
# PACIENTES
# ==================================================

# -------- LISTAR PACIENTES --------
@app.route('/api/pacientes', methods=['GET'])
def listar_pacientes():

    conexao = conectar()

    if conexao:

        cursor = conexao.cursor(dictionary=True)

        cursor.execute("SELECT * FROM tbl_pacientes")

        dados = cursor.fetchall()

        cursor.close()
        fechar_conexao(conexao)

        return jsonify(dados)

    return jsonify([])


# -------- ADICIONAR PACIENTE --------
@app.route('/api/pacientes', methods=['POST'])
def adicionar_paciente():

    dados = request.json

    conexao = conectar()

    if conexao:

        cursor = conexao.cursor()

        sql = '''
        INSERT INTO tbl_pacientes
        (nome_paciente, telefone_paciente, cpf_paciente, email_paciente)
        VALUES (%s, %s, %s, %s)
        '''

        cursor.execute(sql, (
            dados['nome'],
            dados['telefone'],
            dados['cpf'],
            dados['email']
        ))

        conexao.commit()

        cursor.close()
        fechar_conexao(conexao)

        return jsonify({"mensagem": "Paciente adicionado"})

    return jsonify({"erro": "Erro"}), 500


# -------- EDITAR PACIENTE --------
@app.route('/api/pacientes/<int:id>', methods=['PUT'])
def editar_paciente(id):

    dados = request.json

    conexao = conectar()

    if conexao:

        cursor = conexao.cursor()

        sql = '''
        UPDATE tbl_pacientes
        SET nome_paciente=%s,
            telefone_paciente=%s,
            cpf_paciente=%s,
            email_paciente=%s
        WHERE id_paciente=%s
        '''

        cursor.execute(sql, (
            dados['nome'],
            dados['telefone'],
            dados['cpf'],
            dados['email'],
            id
        ))

        conexao.commit()

        cursor.close()
        fechar_conexao(conexao)

        return jsonify({"mensagem": "Paciente atualizado"})

    return jsonify({"erro": "Erro"}), 500


# -------- EXCLUIR PACIENTE --------
@app.route('/api/pacientes/<int:id>', methods=['DELETE'])
def excluir_paciente(id):

    conexao = conectar()

    if conexao:

        cursor = conexao.cursor()

        # REMOVE FEEDBACKS
        sql_feedbacks = '''
        DELETE FROM tbl_feedbacks
        WHERE fk_paciente=%s
        '''

        cursor.execute(sql_feedbacks, (id,))

        # REMOVE AGENDAMENTOS
        sql_agendamentos = '''
        DELETE FROM tbl_agendamentos
        WHERE fk_paciente=%s
        '''

        cursor.execute(sql_agendamentos, (id,))

        # REMOVE PACIENTE
        sql_paciente = '''
        DELETE FROM tbl_pacientes
        WHERE id_paciente=%s
        '''

        cursor.execute(sql_paciente, (id,))

        conexao.commit()

        cursor.close()
        fechar_conexao(conexao)

        return jsonify({"mensagem": "Paciente removido"})

    return jsonify({"erro": "Erro"}), 500


# ==================================================
# AGENDAMENTOS
# ==================================================

# -------- LISTAR AGENDAMENTOS --------
@app.route('/api/agendamentos', methods=['GET'])
def listar_agendamentos():

    conexao = conectar()

    if conexao:

        cursor = conexao.cursor(dictionary=True)

        sql = '''
        SELECT * FROM tbl_agendamentos
        '''

        cursor.execute(sql)

        dados = cursor.fetchall()

        cursor.close()
        fechar_conexao(conexao)

        return jsonify(dados)

    return jsonify([])


# -------- ADICIONAR AGENDAMENTO --------
@app.route('/api/agendamentos', methods=['POST'])
def adicionar_agendamento():

    dados = request.json

    conexao = conectar()

    if conexao:

        cursor = conexao.cursor()

        sql = '''
        INSERT INTO tbl_agendamentos
        (data_hora_agendamento, lab_agendamento, fk_paciente)
        VALUES (%s, %s, %s)
        '''

        cursor.execute(sql, (
            dados['data_hora_agendamento'],
            dados['lab_agendamento'],
            dados['fk_paciente']
        ))

        conexao.commit()

        cursor.close()
        fechar_conexao(conexao)

        return jsonify({"mensagem": "Agendamento adicionado"})

    return jsonify({"erro": "Erro"}), 500


# -------- EXCLUIR AGENDAMENTO --------
@app.route('/api/agendamentos/<int:id>', methods=['DELETE'])
def excluir_agendamento(id):

    conexao = conectar()

    if conexao:

        cursor = conexao.cursor()

        sql = '''
        DELETE FROM tbl_agendamentos
        WHERE id_agendamento=%s
        '''

        cursor.execute(sql, (id,))

        conexao.commit()

        cursor.close()
        fechar_conexao(conexao)

        return jsonify({"mensagem": "Agendamento removido"})

    return jsonify({"erro": "Erro"}), 500


# ==================================================
# FEEDBACKS
# ==================================================

# -------- LISTAR FEEDBACKS --------
@app.route('/api/feedbacks', methods=['GET'])
def listar_feedbacks():

    conexao = conectar()

    if conexao:

        cursor = conexao.cursor(dictionary=True)

        sql = '''
        SELECT * FROM tbl_feedbacks
        '''

        cursor.execute(sql)

        dados = cursor.fetchall()

        cursor.close()
        fechar_conexao(conexao)

        return jsonify(dados)

    return jsonify([])


# -------- ADICIONAR FEEDBACK --------
@app.route('/api/feedbacks', methods=['POST'])
def adicionar_feedback():

    dados = request.json

    conexao = conectar()

    if conexao:

        cursor = conexao.cursor()

        sql = '''
        INSERT INTO tbl_feedbacks
        (profissional_feedback, fk_paciente)
        VALUES (%s, %s)
        '''

        cursor.execute(sql, (
            dados['profissional_feedback'],
            dados['fk_paciente']
        ))

        conexao.commit()

        cursor.close()
        fechar_conexao(conexao)

        return jsonify({"mensagem": "Feedback adicionado"})

    return jsonify({"erro": "Erro"}), 500


# -------- EXCLUIR FEEDBACK --------
@app.route('/api/feedbacks/<int:id>', methods=['DELETE'])
def excluir_feedback(id):

    conexao = conectar()

    if conexao:

        cursor = conexao.cursor()

        sql = '''
        DELETE FROM tbl_feedbacks
        WHERE id_feedback=%s
        '''

        cursor.execute(sql, (id,))

        conexao.commit()

        cursor.close()
        fechar_conexao(conexao)

        return jsonify({"mensagem": "Feedback removido"})

    return jsonify({"erro": "Erro"}), 500


# ==================================================
# START
# ==================================================

if __name__ == '__main__':
    app.run(debug=True)