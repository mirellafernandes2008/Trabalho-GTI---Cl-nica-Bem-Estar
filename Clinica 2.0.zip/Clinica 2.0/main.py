import crud


def menu_principal():
    while True:
        print("\n====== CLÍNICA BEM-ESTAR v0.1 ======")
        print("1 - Pacientes")
        print("2 - Agendamentos")
        print("3 - Feedbacks")
        print("0 - Sair")

        opcao = input("Escolha uma opção: ").strip()

        # PACIENTES
        if opcao == "1":
            while True:
                print("\n--- PACIENTES ---")
                print("1 - Adicionar")
                print("2 - Listar")
                print("3 - Editar")
                print("4 - Excluir")
                print("0 - Voltar")

                op = input("Opção: ").strip()

                if op == "1":
                    crud.adicionar_paciente()
                elif op == "2":
                    crud.listar_pacientes()
                elif op == "3":
                    crud.editar_paciente()
                elif op == "4":
                    crud.excluir_paciente()
                elif op == "0":
                    break

        # AGENDAMENTOS
        elif opcao == "2":
            while True:
                print("\n--- AGENDAMENTOS ---")
                print("1 - Adicionar")
                print("2 - Listar")
                print("3 - Editar")
                print("4 - Excluir")
                print("0 - Voltar")

                op = input("Opção: ").strip()

                if op == "1":
                    crud.adicionar_agendamento()
                elif op == "2":
                    crud.listar_agendamentos()
                elif op == "3":
                    crud.editar_agendamento()
                elif op == "4":
                    crud.excluir_agendamento()
                elif op == "0":
                    break

        # FEEDBACKS
        elif opcao == "3":
            while True:
                print("\n--- FEEDBACKS ---")
                print("1 - Adicionar")
                print("2 - Listar")
                print("3 - Editar")
                print("4 - Excluir")
                print("0 - Voltar")

                op = input("Opção: ").strip()

                if op == "1":
                    crud.adicionar_feedback()
                elif op == "2":
                    crud.listar_feedbacks()
                elif op == "3":
                    crud.editar_feedback()
                elif op == "4":
                    crud.excluir_feedback()
                elif op == "0":
                    break

        elif opcao == "0":
            print("Sistema encerrado.")
            break

        else:
            print("Opção inválida.")


if __name__ == "__main__":
    menu_principal()